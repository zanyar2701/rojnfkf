package app.rojnigar

import android.content.Context

object Store {
    fun p(c: Context) = c.getSharedPreferences("rz", Context.MODE_PRIVATE)
}
