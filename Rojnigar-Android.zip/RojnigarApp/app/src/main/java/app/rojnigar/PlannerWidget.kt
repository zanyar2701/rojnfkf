package app.rojnigar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject

class PlannerWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACT) {
            toggle(c, i.getLongExtra("id", 0L))
            refresh(c)
        }
    }

    companion object {
        const val ACT = "app.rojnigar.TOGGLE"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, PlannerWidget::class.java))) m.updateAppWidget(id, build(c))
        }

        private fun toggle(c: Context, id: Long) {
            val p = Store.p(c)
            val o = JSONObject(p.getString("widget", "{}") ?: "{}")
            val a = o.optJSONArray("tasks") ?: return
            for (k in 0 until a.length()) {
                val t = a.getJSONObject(k)
                if (t.getLong("id") == id) {
                    val nd = 1 - t.optInt("d")
                    t.put("d", nd)
                    o.put("done", o.optInt("done") + if (nd == 1) 1 else -1)
                }
            }
            val ops = JSONArray(p.getString("ops", "[]"))
            ops.put(id)
            p.edit().putString("widget", o.toString()).putString("ops", ops.toString()).apply()
        }

        private fun build(c: Context): RemoteViews {
            val o = JSONObject(Store.p(c).getString("widget", "{}") ?: "{}")
            val rv = RemoteViews(c.packageName, R.layout.widget_large)
            val total = o.optInt("total")
            val done = o.optInt("done")
            rv.setTextViewText(R.id.date, o.optString("date", "ڕۆژنگار"))
            rv.setProgressBar(R.id.progress, 100, if (total > 0) done * 100 / total else 0, false)
            rv.setTextViewText(R.id.stat, "$done / $total")
            val rows = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4)
            val a = o.optJSONArray("tasks")
            for (k in rows.indices) {
                if (a != null && k < a.length()) {
                    val t = a.getJSONObject(k)
                    val mark = if (t.optInt("d") == 1) "✅  " else "⬜  "
                    rv.setViewVisibility(rows[k], View.VISIBLE)
                    rv.setTextViewText(rows[k], mark + t.optString("t") + "  " + t.optString("n"))
                    val it = Intent(c, PlannerWidget::class.java).setAction(ACT)
                        .putExtra("id", t.getLong("id"))
                        .setData(Uri.parse("task://" + t.getLong("id")))
                    rv.setOnClickPendingIntent(
                        rows[k],
                        PendingIntent.getBroadcast(c, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    )
                } else rv.setViewVisibility(rows[k], View.GONE)
            }
            val none = a == null || a.length() == 0
            rv.setViewVisibility(R.id.empty, if (none) View.VISIBLE else View.GONE)
            rv.setTextViewText(R.id.empty, o.optString("empty", ""))
            val open = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.btnOpen, open)
            rv.setOnClickPendingIntent(R.id.btnOpen2, open)
            rv.setTextViewText(R.id.btnOpen2, o.optString("open", "ڕۆژنگار"))
            return rv
        }
    }
}
