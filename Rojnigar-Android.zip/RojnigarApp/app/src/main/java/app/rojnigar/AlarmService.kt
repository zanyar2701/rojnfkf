package app.rojnigar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == "stop") {
            stopAll()
            return START_NOT_STICKY
        }
        val n = build(this, i.getStringExtra("title") ?: "", i.getStringExtra("body") ?: "")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
        play(i.getStringExtra("sound"))
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ stopAll() }, if (i.getStringExtra("kind") == "wake") 90_000L else 30_000L)
        return START_NOT_STICKY
    }

    private fun play(s: String?) {
        try {
            mp?.release()
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            try {
                p.setDataSource(this, Sound.resolve(this, s))
            } catch (e: Exception) {
                p.reset()
                p.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            }
            p.isLooping = true
            p.prepare()
            p.start()
            mp = p
        } catch (_: Exception) {
        }
    }

    private fun stopAll() {
        h.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        try { mp?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CH = "rz_alarm"

        fun build(c: Context, title: String, body: String): Notification {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
                val ch = NotificationChannel(CH, "Rojnigar", NotificationManager.IMPORTANCE_HIGH)
                ch.setSound(null, null)
                ch.enableVibration(true)
                nm.createNotificationChannel(ch)
            }
            val open = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val stop = PendingIntent.getService(
                c, 2, Intent(c, AlarmService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE
            )
            return NotificationCompat.Builder(c, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(open)
                .setFullScreenIntent(open, true)
                .addAction(0, c.getString(R.string.ok), stop)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setOngoing(true)
                .build()
        }
    }
}
