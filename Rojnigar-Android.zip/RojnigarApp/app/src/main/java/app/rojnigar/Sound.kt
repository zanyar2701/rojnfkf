package app.rojnigar

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri

object Sound {
    fun resolve(c: Context, s: String?): Uri = when {
        s.isNullOrBlank() -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        s.startsWith("raw:") -> Uri.parse("android.resource://" + c.packageName + "/raw/" + s.substring(4))
        else -> Uri.parse(s)
    }
}
