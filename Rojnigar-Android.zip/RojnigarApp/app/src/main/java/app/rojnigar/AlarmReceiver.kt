package app.rojnigar

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = Intent(c, AlarmService::class.java)
        i.extras?.let { s.putExtras(it) }
        try {
            ContextCompat.startForegroundService(c, s)
        } catch (e: Exception) {
            // Fallback when the system refuses a foreground service: plain notification + ringtone
            try {
                val n = AlarmService.build(c, i.getStringExtra("title") ?: "", i.getStringExtra("body") ?: "")
                (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
                RingtoneManager.getRingtone(c, Sound.resolve(c, i.getStringExtra("sound")))?.play()
            } catch (_: Exception) {
            }
        }
        if (i.getIntExtra("rep", 0) == 1) Alarms.scheduleAll(c)
    }
}
