package app.rojnigar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

object Alarms {
    private const val DAY = 86_400_000L

    private fun intentFor(c: Context, o: JSONObject): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).setAction("app.rojnigar.ALARM")
            .putExtra("id", o.getInt("id"))
            .putExtra("title", o.optString("title"))
            .putExtra("body", o.optString("body"))
            .putExtra("kind", o.optString("kind"))
            .putExtra("sound", o.optString("sound"))
            .putExtra("rep", o.optInt("rep"))
        return PendingIntent.getBroadcast(c, o.getInt("id"), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun list(c: Context) = JSONArray(Store.p(c).getString("alarms", "[]"))

    fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val a = list(c)
        for (k in 0 until a.length()) am.cancel(intentFor(c, a.getJSONObject(k)))
    }

    fun scheduleAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val a = list(c)
        for (k in 0 until a.length()) {
            val o = a.getJSONObject(k)
            var at = o.getLong("at")
            if (o.optInt("rep") == 1) while (at <= now) at += DAY
            if (at <= now) continue
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), intentFor(c, o))
        }
    }

    fun sync(c: Context, json: String) {
        cancelAll(c)
        Store.p(c).edit().putString("alarms", json).apply()
        scheduleAll(c)
    }
}
