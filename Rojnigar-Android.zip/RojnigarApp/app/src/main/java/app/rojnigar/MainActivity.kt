package app.rojnigar

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var kind = ""
    private var mp: MediaPlayer? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Native")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.onNativeResume&&window.onNativeResume()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        var uri: Uri? = null
        var name = ""
        if (req == 101) {
            uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (uri != null) name = RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: ""
        } else if (req == 102) {
            uri = data.data
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                contentResolver.query(uri, null, null, null, null)?.use {
                    if (it.moveToFirst()) {
                        val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ix >= 0) name = it.getString(ix) ?: ""
                    }
                }
            }
        }
        if (uri == null) return
        val js = "window.onNativeSound&&window.onNativeSound(" + JSONObject.quote(kind) + "," +
            JSONObject.quote(uri.toString()) + "," + JSONObject.quote(name) + ")"
        web.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun syncAlarms(json: String) {
            try { Alarms.sync(this@MainActivity, json) } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun saveWidget(json: String) {
            Store.p(this@MainActivity).edit().putString("widget", json).apply()
            PlannerWidget.refresh(this@MainActivity)
        }

        @JavascriptInterface
        fun takeOps(): String {
            val p = Store.p(this@MainActivity)
            val s = p.getString("ops", "[]") ?: "[]"
            p.edit().putString("ops", "[]").apply()
            return s
        }

        @JavascriptInterface
        fun pickSystemSound(k: String) {
            kind = k
            runOnUiThread {
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                startActivityForResult(i, 101)
            }
        }

        @JavascriptInterface
        fun pickFile(k: String) {
            kind = k
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "audio/*"
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                startActivityForResult(i, 102)
            }
        }

        @JavascriptInterface
        fun preview(s: String) {
            runOnUiThread {
                try {
                    try { mp?.release() } catch (_: Exception) {}
                    val p = MediaPlayer()
                    p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
                    p.setDataSource(this@MainActivity, Sound.resolve(this@MainActivity, s))
                    p.prepare()
                    p.start()
                    p.setOnCompletionListener { it.release() }
                    mp = p
                } catch (_: Exception) {
                }
            }
        }
    }
}
